//window.addEventListener("beforeunload", re);
function re(){
    alert("NOT TODAY");
}

alert("loaded");
window.onunload = confirmExit;
window.onbeforeunload = confirmExit;
function confirmExit() {
  alert("NEVER");
  return "You have attempted to leave this page.  If you have made any changes to the fields without clicking the Save button, your changes will be lost.  Are you sure you want to exit this page?";
}

html ='<p> <button type="button" id="closeTabs">Click me to close the selected tabs!</button> </p>';
document.getElementById("tabList").innerHTML += html;

let button = document.getElementById("closeTabs");
button.addEventListener("click", clickAlert);

function clickAlert(){
  //document.documentElement.innerHTML = "<!DOCTYPE html> <html> <h1> <pre> UNBUNKY </pre> </h1> </html>";
  alert("re");
}

/*$.getScript("test-page-script.js", function(response, status){
  console.log(response);
});
*/
alert("after");