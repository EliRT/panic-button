let color = '#ff0000';
var tabDict = {};

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.set({ color });
});

console.log('Set listener for tabs!');

chrome.tabs.onUpdated.addListener(tabUpdated);    //adds a newly created tab to the dictionary
function tabUpdated(tabId, changeInfo, tab) {

  tabDict[tabId] = tab.title;
  console.log('tabId is '+ tabId +", and was " + tab.id);
  console.log(tabDict);
  /*chrome.scripting.executeScript({
    target: {
      tabId: tab.id,
      allFrames: true,
    },
    files: ["content-script.js"],
  });*/
  //chrome.runtime.sendMessage({tabs: {}, target: tabId, msg: "for content_script"});
}

/*chrome.tabs.onCreated.addListener(async (tab) => {
  chrome.scripting.executeScript({
    target: {
      tabId: tab.id,
      allFrames: true,
    },
    files: ["content-script.js"],
  });
});*/

chrome.runtime.onMessage.addListener(sendTabs);
function sendTabs(request, sender, sendResponse) {
  let obj = {tabs: null};

  if (request.status == "getTabs"){
    obj.tabs = tabDict;
    
    chrome.runtime.sendMessage(obj);
    console.log("sent tabs!");
  }

  else if (request.status == "closingTab"){
    chrome.tabs.query({active: true}, checkLiveness);
    delete tabDict[request.tabId];
    chrome.runtime.sendMessage({tabs: tabDict});
  }

  else if (request.msg == "print"){
    console.log(request.content);
  }
}

function updatetabDict(tabs){
  for(let i=0; i<tabs.length; i++){
    console.log(tabs[i].id);
  }
}

chrome.tabs.onRemoved.addListener(removeTab);     //removes a recently closed tab from the dictionary
function removeTab(tabId, removeinfo){
  chrome.tabs.query({active: true}, checkLiveness);
  console.log(tabId);
  delete tabDict[tabId];
}

function checkLiveness(activeTabs){
  console.log(activeTabs);
}